Folder: DatasetGenerationProgs
Purpose: The SAS files in this folder are responsible for generating the simulated datasets that serve as the
"testbed" for the Harrall Algorithm manuscript. This readme file contains documentation of the purpose of each
file involved throughout this process.

Files:
	- p01_GoodDataGeneration: This file contains a macro that generates "correct" height and weight data from 
		the Preece-Baines model. Is used in p100_DatasetGeneration.
	- p100_CupsCapsSummaryStats: This file contains a macro that generates summary statistics for the total number
		of caps and cups introduced into each simulated dataset.
	- p100_DatasetGeneration: This file contains the macro that calls the other macros in this folder and generates
		the simulated datasets.
	- p100_GenerateCapsCups: This file contains the macro that introduces the cups and caps into the "correct" height
		and weight trajectories.
	- p100_GenerateRepeats: This file contains the macro that introduces repeats into the "correct" height and weight
		trajectories.
	- p100_RepeatsSummaryStats: This file contains the macro that captures summary statistics for the generation 
		of repeats into the clean dataset.


For replication of the simulated datasets used in this simulation, the following seeds were entered into the call:
/*******************************************************************************************/
/*  Condition 1 | Population parameter level: 1    |  Dirt Level: 1  |   Seed: 9           */
/*  Condition 2 | Population parameter level: 1    |  Dirt Level: 2  |   Seed: 8           */
/*  Condition 3 | Population parameter level: 1    |  Dirt Level: 3  |   Seed: 10          */
/*  Condition 4 | Population parameter level: 2    |  Dirt Level: 1  |   Seed: 11          */
/*  Condition 5 | Population parameter level: 2    |  Dirt Level: 2  |   Seed: 12          */
/*  Condition 6 | Population parameter level: 2    |  Dirt Level: 3  |   Seed: 13          */
/*  Condition 7 | Population parameter level: 3    |  Dirt Level: 1  |   Seed: 14          */
/*  Condition 8 | Population parameter level: 3    |  Dirt Level: 2  |   Seed: 15          */
/*  Condition 9 | Population parameter level: 3    |  Dirt Level: 3  |   Seed: 16          */
/*******************************************************************************************/