File: AlgorithmProgs

This file contains various versions of the Harrall Algorithm

Folders:
	- FinalAlgorithm: This folder contains the raw version of the Harrall Algorithm. Various
		summary statistics and frequency tables will be output throughout the iterations
		that are undergone. 
	- FinalAlgorithm_noOutput: This folder contains a version of the Harrall Algorithm that 
		does not produce any supplemental output. 
	- RCode: This folder contains two function files that are needed in order to run the 
		Harrall Algorithm in R.
	- ExamplePrograms: This folder contains a guide on how to use the SAS and R versions of
		the Harrall Algorithm



Copyright 2023 The Regents of the University of the Colorado
The Harrall Algorithm is released under the GNU General Public License, version 2.