# A novel cleaning algorithm for longitudinal pediatric height and weight has higher specificity than published approaches

* Kylie K. Harrall, Sarah Bird, Keith E. Muller, Maya Payton, Anna Bellatorre, Deborah H. Glueck, and Dana Dabelea


This folder contains all files needed for the use of the Harrall Algorithm, a novel cleaning algorithm. This set of programs
	excludes all output (including the summary excel sheet) for a more seamless (and less cluttered) simulation set up.

Files:
	- p003_IterativeHeight_noOutput
	- p003_IterativeWeight_noOutput
	- p003_NumbersMacro_noOutput
	- p004_HeightCleanStep1_noOutput
	- p004_HeightCleanStep2_noOutput
	- p004_WeightCleanStep1_noOutput
	- p004_WeightCleanStep2_noOutput

Useage:

At the beginnning of the SAS file, include all of these files in your session using this syntax:
	%include "path-to-file\p003_IterativeHeight.sas";

After loading these into your session, you may run the Harrall algorithm using the following syntax for height:

%iterativeLoop( InLib         =  ,
                OutLib        =  ,
                InPath        =  , 
                OutPath       =  ,
                InDS          =  ,
                OutDS         =  ,
                PIDVar        =  ,
                HeightVar     =  , 
                AgeVar        =  ,
                SourceVar     =  ,
                MaxIterations =  ,
                MaxPeaks      =  ,
                OutFileExt    = );

The required arguments are like so:
	- InLib: the library the dataset for analysis is stored in
        - OutLib: the library the output data will be stored in
        - InPath: Path to the raw data on laptop
        - OutPath: Desired path to output dataset
        - InDS: The name of the input dataset
        - OutDS: Name of desired output dataset
        - HeightVar: Name of height variable in original dataset
        - AgeVar: Name of age variable in original dataset
	- SourceVar: Name of variable that establishes order in which to handle duplicate values. This variable should denote
		the order in which values should be kept. When sorted by SAS, the first by group will be retained in the dataset.
        - MaxIterations: The number of iterations to be completed as a maximum for computational efficiency
        - MaxPeaks: The number of peaks that the data should contain as an upper bound (typically 0)
	- OutFileExt: Specifies desired format of exported excel tabular data


Similarly, the call for weight is:

%WeightLoop(    InLib         =  ,
                OutLib        =  , 
                InPath        =  ,
                OutPath       =  ,
                InDS          =  ,
                OutDS         =  ,
                PIDVar        =  ,
                AgeVar        =  ,
                WeightVar     =  ,
                SourceVar     =  ,
                MaxIterations =  ,
                MaxPeaks      =  ,
                OutFileExt    = );


The arguments required are as follows:
	- InLib: the library the dataset for analysis is stored in
        - OutLib: the library the output data will be stored in
        - InPath: Path to the raw data on laptop
        - OutPath: Desired path to output dataset
        - InDS: The name of the input dataset
        - OutDS: Name of desired output dataset
	- PIDVar: Name of participant identifier
        - WeightVar: Name of weight variable in original dataset
        - AgeVar: Name of age variable in original dataset
	- SourceVar: Name of variable that establishes order in which to handle duplicate values. This variable should denote
		the order in which values should be kept. When sorted by SAS, the first by group will be retained in the dataset.
        - MaxIterations: The number of iterations to be completed as a maximum for computational efficiency
        - MaxPeaks: The number of peaks that the data should contain as an upper bound (typically 0)
	- OutFileExt: Specifies desired format of exported excel tabular data









