Folder: RCode
Purpose: This set of programs contains a version of the Harrall algorithm that has been converted to an R program. 


Files: 
	- p002_FunctionFileHeight.R: This program contains all functions needed for the implementation of
		the Harrall algorithm with height data
	- p002_FunctionFileWeight.R: This program contains all functions needed for implementation with
		weight data