#####################################################################################
#
#
# File: p002_FunctionFileWeight.R
# Purpose: This R file contains all of the functions needed to run the 
#             Harrall algorithm. Detailed documentation of how to structure
#             the run of the algorithmic process can be found in the 
#             example code folder.
#
#
#####################################################################################




################################################################################
# PROGRAM: Remove_Repeats_WT
# DESCRIPTION: This function will remove all repeated weight observations and
#               identify preliminary peaks in the supplied data set.
################################################################################

################################################################################
#   INPUT:
#           data: the data set that the algorithm will be ran on. 
################################################################################
Remove_Repeats_WT <- function( data ) {
  
  # removing missing values of weight from the dataset
  data_noMissing <- data %>% filter(!is.na(wtkg))
  
  ####################
  # Performing a data check: are there any negative values for weight or age?
  ###################
  
  # Subsetting the data to include only the negative age observations. Then an if
  # then set of conditionals will evaluate according to the following logic:
  #       - if the dataset contains no observations of negative age, a message will
  #             be put to the console notifying the user that no ages are negative
  #       - if the dataset contains negative values of age, then a warning will be 
  #             output at the completion of the program notifying the user that 
  #             the dataset contains negAgeVa number of negative ages
  negAge <- data_noMissing %>% filter(ageyearsnew < 0)
  if (nrow(negAge) == 0) {
    message("NOTE: All values of age are positive")
  } else {
    negAgeVa <- nrow(negAge)
    warning(paste("WARNING: There are", negAgeVa, "negative ages present in the data"))
  }
  
  # Subsetting the data to include only the negative weight observations. Then an if
  # then set of conditionals will evaluate according to the following logic:
  #       - if the dataset contains no observations of negative weight, a message will
  #             be put to the console notifying the user that no heights are negative
  #       - if the dataset contains negative values of weight, then a warning will be 
  #             output at the completion of the program notifying the user that 
  #             the dataset contains negHtVa number of negative weights
  negWt <- data_noMissing %>% filter(wtkg < 0)
  if (nrow(negWt) == 0) {
    message("NOTE: All values of weight are positive")
  } else {
    negWtVa <- nrow(negWt)
    warning(paste("There are", negWtVa, "negative weights present in the data"))
  }
  
  #############################################################################
  # Computing first iteration of algorithm                                    #
  #############################################################################
  
  
  
  ##################
  ## Step One: Sort the data as needed for first calculation of slope
  ##################
  
  # ordering the dataset by age according to PID, age, and source values
  data_algo <- data_noMissing %>% 
    arrange(PID, ageyearsnew, source, .by_group=TRUE) 
  
  # This step will remove duplicate observations when there are two same ages. This code will
  #     retain the observation that is first in sorting order
  # data_noDup <- data_algo %>%
  #   group_by(PID, ageyearsnew, source) %>%
  #   slice(1) %>%
  #   ungroup()
  
  data_noDup <- data_algo %>%
    group_by(PID, ageyearsnew) %>%
    slice(1) %>%
    ungroup()
  
  ##################
  ## Step One: Calculate Slope 
  ##################
  
  ## calculate the lagged height and age variables along with age difference
  data_algo <- data_noDup %>% group_by(PID) %>% 
    mutate(prev_wtkg=lag(wtkg, default=0), 
           prev_age=lag(ageyearsnew, default=0), 
           ageDiff = ageyearsnew-prev_age)
  
  ## calculate second lagged height and age variables along with second age diff
  data_algo2 <- data_algo %>% 
    mutate(prev2_age = lag(prev_age, default=0), 
           prev2_wtkg = lag(prev_wtkg, default=0), 
           XB_ageDiff = ageyearsnew - prev2_age)
  
  # change the zeros to avoid division by zero
  data_algo2$ageDiff <- ifelse(data_algo2$ageDiff == 0, 0.001, data_algo2$ageDiff)
  data_algo2$XB_ageDiff <- ifelse(data_algo2$XB_ageDiff == 0, 0.001, data_algo2$XB_ageDiff)
  
  
  # we can determine slope values here using the following logic: 
  #   group by PID, then if the observation is NOT the first in the PID group, we will calculate
  #       the slope. If it is the first observation in the PID group, we will assign the slope 
  #       variable a value of NA.
  data_algo3 <- data_algo2 %>% group_by(PID) %>% 
    mutate(wtslope = ifelse( row_number() != 1, (wtkg-prev_wtkg)/ageDiff, NA),
           XB_slope = ifelse( row_number() != 1, (wtkg-prev2_wtkg)/XB_ageDiff, NA))
  
  
  ##################
  ## Step Two: Determine direction of slope
  ##      if a slope = 0, reassign it as 0.001
  ##      if a slope = NA, reassign it as 0.001
  ##################
  
  # this will determine the direction of the slope using the following logic:
  #     If an observation is the first in a PID group, we will assign the sign
  #     a value of NA. If it is not the first in a PID group, we will assign the
  #     sign variable a value of 1 if the slope is equal to or greater than 0, 
  #     otherwise we will assign the sign variable a value of -1
  data_algo4 <- data_algo3 %>% group_by(PID) %>% 
    mutate(sign = ifelse( row_number() == 1, NA, ifelse( wtslope >= 0, 1, -1)))
  
  ##################
  ## Step Three: Compute Lag of Signs
  ##################
  
  # this will compute the lag of the signs
  data_algo5 <- data_algo4 %>% group_by(PID) %>% mutate(prev_sign = lag(sign, default=0))
  
  ##################
  ## Step Four: Compute Sum of Signs
  ##################
  
  # this step will sum the sign and prev_sign variables to obtain the sum of signs
  data_algo6 <- data_algo5 %>% group_by(PID) %>% mutate(SumSigns = sign+prev_sign)
  
  ##################
  ## Step Five: Compute Lagged Sum of Signs
  ##################
  
  # this step will computed the lagged sum of signs 
  data_algo7 <- data_algo6 %>% group_by(PID) %>% mutate(prev_SumSigns= lag(SumSigns, default=99))
  
  ##################
  ## Step Six: Determine Possible Cups: where sum of signs = 0 and lag(sum of signs)=2
  ##################
  
  # this step will determine the possible cups with the following logic:
  #     if the sum of signs is 0 and previous (lagged) sum of signs is 2, then the 
  #     posPeakCup (indiciator) variable obtains a value of 1 and is a potential cup. 
  #     otherwise, the indicator variable takes on a value of 0.
  # data_algo <- data_algo %>% group_by(PID) %>% mutate(posPeakCup = ifelse( (sumSigns == 0)&(prev_SumSigns==2), 1, 0)) %>%
  #   mutate(posPeakCup = ifelse( is.na(posPeakCup), 0, posPeakCup))
  
  # we will create a new variable that will contain the ordering of the dataset
  data_algo_posCups <- data_algo7 %>% ungroup() %>% mutate(Order = 1:n())
  
  
  ##################
  ## Step Seven: Invert dataset, (by PID and descending age), find reverse lag sum of signs
  ##################
  
  # first we'll reverse the order by the order variable we created
  rev_Data_algo <- data_algo_posCups  %>% arrange(desc(Order), .by_group = TRUE) 
  
  # now we can find the reverse sum of signs 
  rev_Data_algo2 <- rev_Data_algo %>% 
    group_by(PID) %>%
    mutate(prev_Rev_SumSigns = lag(SumSigns, default=NA), 
           prev_Rev_wtkg = lag(wtkg, default=0), 
           prev_Rev_age = lag(ageyearsnew, default=0)) %>%
    ungroup()
  
  
  # this step will create additional lagged variables
  rev_Data_algo3 <- rev_Data_algo2 %>%
    mutate(prev2_Rev_wtkg = lag(prev_Rev_wtkg, default=0), 
           prev2_Rev_age  = lag(prev_Rev_age, default=0))
  
  
  
  ##################
  ## Step Eight: Invert dataset, (by PID and ascending age), to original order
  ##################
  
  # this step will invert the dataset to the original order
  # data.algo <- rev_Data_algo %>% group_by(PID) %>% arrange(ageyearsnew, .by_group = TRUE) 
  data.algo <- rev_Data_algo3 %>% group_by(PID) %>% arrange(Order, .by_group = TRUE) 
  
  # this step will create the AY_ageDiff and BY_ageDiff variables
  data.algo2 <- data.algo %>% group_by(PID) %>% arrange(ageyearsnew, .by_group = TRUE) %>%
    mutate(AY_ageDiff = (prev2_Rev_age- ageyearsnew), 
           BY_ageDiff = (prev_Rev_age - ageyearsnew))
  
  # now we will assign an age difference of 0 to preserve slope calculations
  data.algo2$AY_ageDiff <- ifelse(data.algo2$AY_ageDiff == 0, 0.001, data.algo2$AY_ageDiff)
  data.algo2$BY_ageDiff <- ifelse(data.algo2$BY_ageDiff == 0, 0.001, data.algo2$BY_ageDiff)
  
  
  # this step will calculate the slopes with the following logic: 
  #     if the observation is not the first in the PID group, then the slope will be
  #     calculated like normal, otherwise a value of NA will be assigned to the slope
  #     value.
  data.algo3 <- data.algo2 %>% group_by(PID) %>% 
    mutate(AY_slope = ifelse( row_number() != 1, (prev2_Rev_wtkg - wtkg) / AY_ageDiff, NA),
           BY_slope = ifelse( row_number() != 1, (prev_Rev_wtkg  - wtkg) / BY_ageDiff, NA)) 
  
  
  ##################
  ## Step Nine: Determine possible caps: where sum of signs=2 and lag(sum of signs)=0
  ##################
  
  # this step will create the potential cap indicator variable
  data.algo4 <- data.algo3 %>% 
    group_by(PID) %>% 
    mutate(PosPeakCap = ifelse( ( is.na(SumSigns) & (prev_Rev_SumSigns==0)), 1, 
                                ifelse( ( abs(SumSigns) == 2)&(prev_Rev_SumSigns==0), 1, 0))) %>%
    mutate(PosPeakCap = ifelse( is.na(PosPeakCap), 0, PosPeakCap)) %>% 
    mutate(PosPeakCup = ifelse( is.na(SumSigns) & (prev_Rev_SumSigns==0), 1, 
                                ifelse( (SumSigns == 0)&( abs(prev_SumSigns) == 2), 1, 0))) %>%
    mutate(PosPeakCup = ifelse( is.na(PosPeakCup), 0, PosPeakCup))
  
  ##################
  ## Step Ten:
  ##    Find final caps: it's slope it greater than some mag
  ##    Find final cups: if it was a possible cup and ruled out as a cap
  ##################
  
  # this step will create the cap and cup difference variables and additional lagged prev_cap_diff variable
  #   incrementally
  data.algo.1 <- data.algo4 %>% group_by(PID) %>% mutate(cap_diff = (AY_slope - wtslope),
                                                         cup_diff = (XB_slope - BY_slope)) %>% 
    mutate(prev_cap_diff = lag(cap_diff, default=NA))
  
  # now we'll invert the dataset to reverse lag the cup difference
  data.algo.2 <- data.algo.1 %>% 
    ungroup() %>%
    arrange(desc(Order), .by_group = TRUE) %>%
    mutate(prev_Rev_cup_diff = lag(cup_diff, default=NA))
  
  
  # reverting back to original orientation
  data.algo.3 <- data.algo.2 %>% arrange(PID, ageyearsnew) 
  
  
  # if then logic to determine if a possible peak is actually a peak
  data_Peaks <- data.algo.3 %>% 
    mutate(Peak = ifelse( (PosPeakCap == 1) & (PosPeakCup == 1), 1,
                          ifelse((PosPeakCap == 1) & (cap_diff < prev_Rev_cup_diff), 1, 
                                 ifelse( (PosPeakCap == 1) & (cap_diff == prev_Rev_cup_diff), 1, 
                                         ifelse( (PosPeakCup == 1) & (cup_diff < prev_cap_diff),1,
                                                 ifelse ((PosPeakCup == 1) & (cup_diff == prev_cap_diff), 1,0  )))))) %>% # end of mutate 
    ungroup()
  
  ##################
  ## Step Eleven:
  ##    Cleaning and Removing Peaks
  ##################
  
  ## this will assign a value of 0 to any Peak value that is NA
  # data_Peaks <- data_Peaks %>% group_by()
  data_Peaks <- data_Peaks %>% group_by(PID) %>%
    mutate(Peak = ifelse( is.na(Peak), 0, Peak))
  
  # This will create an indicator variable, lgcm_Repeat, that determines if a height value is repeated or not
  #         0 means not repeated, 1 means repeat 
  data_Peaks <- data_Peaks %>% group_by(PID) %>% 
    mutate(wtkg_Repeat=ifelse( (wtslope != 0) | (is.na(wtslope)) , 0, 1))
  
  # this will filter the dataset, removing all height repeats
  data_Peaks_rm <- data_Peaks %>% filter(wtkg_Repeat == 0)
  
  # return the dataset with the repeated heights information removed
  return( list(dataset_it0 = data_Peaks_rm, dataset_notrm = data_Peaks))
  
}








################################################################################
# PROGRAM: Remove_Peaks_HT
# DESCRIPTION: This function will remove all repeated height observations and
#               remove peaks in the supplied dataset.
################################################################################

################################################################################
#   INPUT:
#           data:         the dataset that the algorithm will be ran on. 
################################################################################


Remove_Peaks_WT <- function(data) {
  #############################################################################
  # Computing first iteration of algorithm                                    #
  #############################################################################
  
  # extracting data from list input
  data_sub <- data[[1]]
  
  ##################
  ## Step One: Sort the data as needed for first calculation of slope
  ##################
  
  # first we will take the data, sort it by ascending PID number, and arrange it by ascending age
  data_noDup <- data_sub %>% 
    arrange(PID, ageyearsnew, source, .by_group=TRUE) 
  
  ##################
  ## Step One: Calculate Slope 
  ##################
  
  ## calculate the lagged height and age variables along with age difference
  data_algo <- data_noDup %>% group_by(PID) %>% 
    mutate(prev_wtkg=lag(wtkg, default=0), 
           prev_age=lag(ageyearsnew, default=0), 
           ageDiff = ageyearsnew-prev_age)
  
  ## calculate second lagged height and age variables along with second age diff
  data_algo2 <- data_algo %>% 
    mutate(prev2_age = lag(prev_age, default=0), 
           prev2_wtkg = lag(prev_wtkg, default=0), 
           XB_ageDiff = ageyearsnew - prev2_age)
  
  # change the zeros to avoid division by zero
  data_algo2$ageDiff <- ifelse(data_algo2$ageDiff == 0, 0.001, data_algo2$ageDiff)
  data_algo2$XB_ageDiff <- ifelse(data_algo2$XB_ageDiff == 0, 0.001, data_algo2$XB_ageDiff)
  
  
  # we can determine slope values here using the following logic: 
  #   group by PID, then if the observation is NOT the first in the PID group, we will calculate
  #       the slope. If it is the first observation in the PID group, we will assign the slope 
  #       variable a value of NA.
  data_algo3 <- data_algo2 %>% group_by(PID) %>% 
    mutate(wtslope = ifelse( row_number() != 1, (wtkg-prev_wtkg)/ageDiff, NA),
           XB_slope = ifelse( row_number() != 1, (wtkg-prev2_wtkg)/XB_ageDiff, NA)) %>%
    mutate(slope_thres = case_when(
      ageyearsnew < 3 ~ 3,
      (ageyearsnew >= 3) & (ageyearsnew < 4) ~ 3.3,
      (ageyearsnew >= 4) & (ageyearsnew < 5) ~ 3.7,
      (ageyearsnew >= 5) & (ageyearsnew < 6) ~ 4,
      (ageyearsnew >= 6) & (ageyearsnew < 7) ~ 4.4,
      (ageyearsnew >= 7) & (ageyearsnew < 8) ~ 5.2,
      (ageyearsnew >= 8) & (ageyearsnew < 9) ~ 6,
      (ageyearsnew >= 9) & (ageyearsnew < 10) ~ 6.8,
      (ageyearsnew >= 10) & (ageyearsnew < 11) ~ 7.3,
      (ageyearsnew >= 11) & (ageyearsnew < 12) ~ 7.2,
      (ageyearsnew >= 12) & (ageyearsnew < 13) ~ 6.5,
      (ageyearsnew >= 13) & (ageyearsnew < 14) ~ 5.3,
      (ageyearsnew >= 14) & (ageyearsnew < 15) ~ 4,
      (ageyearsnew >= 15) & (ageyearsnew < 16) ~ 2.7,
      (ageyearsnew >= 16) & (ageyearsnew < 17) ~ 1.8,
      (ageyearsnew >= 17) & (ageyearsnew < 18) ~ 1.3,
      is.na(ageyearsnew) ~ NA,
      .default = 1.3
    )) %>%
    mutate(neg_slope_thres = -slope_thres) %>%
    mutate(over_thres = ifelse( (wtslope > slope_thres), 1,
                                ifelse( (wtslope < neg_slope_thres), 1, 0))) 
  
  
  
  ##################
  ## Step Two: Determine direction of slope
  ##      if a slope = 0, reassign it as 0.001
  ##      if a slope = NA, reassign it as 0.001
  ##################
  
  # this will determine the direction of the slope using the following logic:
  #     If an observation is the first in a PID group, we will assign the sign
  #     a value of NA. If it is not the first in a PID group, we will assign the
  #     sign variable a value of 1 if the slope is equal to or greater than 0, 
  #     otherwise we will assign the sign variable a value of -1
  data_algo4 <- data_algo3 %>% group_by(PID) %>% 
    mutate(sign = ifelse( row_number() == 1, NA, ifelse( wtslope >= 0, 1, -1)))
  
  ##################
  ## Step Three: Compute Lag of Signs
  ##################
  
  # this will compute the lag of the signs
  data_algo5 <- data_algo4 %>% group_by(PID) %>% mutate(prev_sign = lag(sign, default=0))
  
  
  ##################
  ## Step Four: Compute Sum of Signs
  ##################
  
  # this step will sum the sign and prev_sign variables to obtain the sum of signs
  data_algo6 <- data_algo5 %>% group_by(PID) %>% mutate(SumSigns = sign+prev_sign)
  
  ##################
  ## Step Five: Compute Lagged Sum of Signs
  ##################
  
  # this step will computed the lagged sum of signs 
  data_algo7 <- data_algo6 %>% group_by(PID) %>% mutate(prev_SumSigns= lag(SumSigns, default=99))
  
  
  ##################
  ## Step Six: Determine Possible Cups: where sum of signs = 0 and lag(sum of signs)=2
  ##################
  
  # this step will determine the possible cups with the following logic:
  #     if the sum of signs is 0 and previous (lagged) sum of signs is 2, then the 
  #     posPeakCup (indiciator) variable obtains a value of 1 and is a potential cup. 
  #     otherwise, the indicator variable takes on a value of 0.
  # data_algo <- data_algo %>% group_by(PID) %>% mutate(posPeakCup = ifelse( (sumSigns == 0)&(prev_SumSigns==2), 1, 0)) %>%
  #   mutate(posPeakCup = ifelse( is.na(posPeakCup), 0, posPeakCup))
  
  # we will create a new variable that will contain the ordering of the dataset
  data_algo_posCups <- data_algo7 %>% ungroup() %>% mutate(Order = 1:n())
  
  ##################
  ## Step Seven: Invert dataset, (by PID and descending age), find reverse lag sum of signs
  ##################
  
  # first we'll reverse the order by the order variable we created
  rev_Data_algo <- data_algo_posCups  %>% arrange(desc(Order), .by_group = TRUE) 
  
  
  # now we can find the reverse sum of signs 
  rev_Data_algo2 <- rev_Data_algo %>% 
    group_by(PID) %>%
    mutate(prev_Rev_SumSigns = lag(SumSigns, default=NA), 
           prev_Rev_wtkg = lag(wtkg, default=0), 
           prev_Rev_age = lag(ageyearsnew, default=0)) %>%
    ungroup()
  
  
  # this step will create additional lagged variables
  rev_Data_algo3 <- rev_Data_algo2 %>%
    mutate(prev2_Rev_wtkg = lag(prev_Rev_wtkg, default=0), 
           prev2_Rev_age  = lag(prev_Rev_age, default=0))
  
  
  ##################
  ## Step Eight: Invert dataset, (by PID and ascending age), to original order
  ##################
  
  # this step will invert the dataset to the original order
  # data.algo <- rev_Data_algo %>% group_by(PID) %>% arrange(ageyearsnew, .by_group = TRUE) 
  data.algo <- rev_Data_algo3 %>% group_by(PID) %>% arrange(Order, .by_group = TRUE) 
  
  # this step will create the AY_ageDiff and BY_ageDiff variables
  data.algo2 <- data.algo %>% group_by(PID) %>% arrange(ageyearsnew, .by_group = TRUE) %>%
    mutate(AY_ageDiff = (prev2_Rev_age- ageyearsnew), 
           BY_ageDiff = (prev_Rev_age - ageyearsnew))
  
  # now we will assign an age difference of 0 to preserve slope calculations
  data.algo2$AY_ageDiff <- ifelse(data.algo2$AY_ageDiff == 0, 0.001, data.algo2$AY_ageDiff)
  data.algo2$BY_ageDiff <- ifelse(data.algo2$BY_ageDiff == 0, 0.001, data.algo2$BY_ageDiff)
  
  
  # this step will calculate the slopes with the following logic: 
  #     if the observation is not the first in the PID group, then the slope will be
  #     calculated like normal, otherwise a value of NA will be assigned to the slope
  #     value.
  data.algo3 <- data.algo2 %>% group_by(PID) %>% 
    mutate(AY_slope = ifelse( row_number() != 1, (prev2_Rev_wtkg - wtkg) / AY_ageDiff, NA),
           BY_slope = ifelse( row_number() != 1, (prev_Rev_wtkg  - wtkg) / BY_ageDiff, NA))
  
  ##################
  ## Step Nine: Determine possible caps: where sum of signs=2 and lag(sum of signs)=0
  ##################
  
  # this step will create the potential cap indicator variable
  data.algo4 <- data.algo3 %>% 
    group_by(PID) %>% 
    mutate(PosPeakCap = ifelse( ( is.na(SumSigns) & (prev_Rev_SumSigns==0)), 1, 
                                ifelse( ( abs(SumSigns) == 2)&(prev_Rev_SumSigns==0), 1, 0))) %>%
    mutate(PosPeakCap = ifelse( is.na(PosPeakCap), 0, PosPeakCap)) %>% 
    mutate(PosPeakCup = ifelse( is.na(SumSigns) & (prev_Rev_SumSigns==0), 1, 
                                ifelse( (SumSigns == 0)&( abs(prev_SumSigns) == 2), 1, 0))) %>%
    mutate(PosPeakCup = ifelse( is.na(PosPeakCup), 0, PosPeakCup))
  
  ##################
  ## Step Ten:
  ##    Find final caps: it's slope it greater than some mag
  ##    Find final cups: if it was a possible cup and ruled out as a cap
  ##################
  
  # this step will create the cap and cup difference variables and additional lagged prev_cap_diff variable
  #   incrementally
  data.algo.1 <- data.algo4 %>% group_by(PID) %>% mutate(cap_diff = (AY_slope - wtslope),
                                                         cup_diff = (XB_slope - BY_slope)) %>% 
    mutate(prev_cap_diff = lag(cap_diff, default=NA))
  
  
  # now we'll invert the dataset to reverse lag the cup difference
  data.algo.2 <- data.algo.1 %>% 
    ungroup() %>%
    arrange(desc(Order), .by_group = TRUE) %>%
    mutate(prev_Rev_cup_diff = lag(cup_diff, default=NA))
  
  
  # reverting back to original orientation
  data.algo.3 <- data.algo.2 %>% arrange(PID, ageyearsnew)   
  
  
  # if then logic to determine if a possible peak is actually a peak
  data_Peaks <- data.algo.3 %>% 
    mutate(Peak = ifelse( (PosPeakCap == 1) & (PosPeakCup == 1), 1,
                          ifelse((PosPeakCap == 1) & (cap_diff < prev_Rev_cup_diff), 1, 
                                 ifelse( (PosPeakCap == 1) & (cap_diff == prev_Rev_cup_diff), 1, 
                                         ifelse( (PosPeakCup == 1) & (cup_diff < prev_cap_diff),1,
                                                 ifelse ((PosPeakCup == 1) & (cup_diff == prev_cap_diff), 1,0  )))))) %>% # end of mutate 
    ungroup()
  
  
  ##############################################
  #   Remove weight peaks at a threshold of wtslope
  ##############################################
  
  # find the absolute value of the user-provided wtThreshold variable
  # absWtThreshold = abs(wtThreshold)
  
  # Now we can flag observations that are beyond this wtThreshold value
  data_truePeaks <- data_Peaks %>% group_by(PID) %>% 
    mutate( wtslope_flag = ifelse( is.na(wtslope), 0,
                                   ifelse( (over_thres == 1) & (Peak == 1), 1, 0)))
  
  
  
  ##################
  ## Step Eleven:
  ##    Cleaning and Removing Peaks
  ##################
  
  ## this will assign a value of 0 to any Peak value that is NA
  data_truePeaks_1 <- data_truePeaks %>% group_by(PID) %>%
    mutate(wtslope_flag = ifelse( is.na(wtslope_flag), 0, wtslope_flag))
  
  # This will create an indicator variable, lgcm_Repeat, that determines if a height value is repeated or not
  #         0 means not repeated, 1 means repeat 
  data_truePeaks_2 <- data_truePeaks_1 %>% group_by(PID) %>% 
    mutate(wtkg_Repeat=ifelse( (wtslope != 0) | (is.na(wtslope)) , 0, 1))
  
  # this will filter the dataset, removing all weight repeats
  data_noRpHt_Peaks <- data_truePeaks_2 %>% filter(wtkg_Repeat == 0)
  
  # this will filter the dataset, removing all peaks
  data_noPeaks <- data_noRpHt_Peaks %>% filter(wtslope_flag == 0)
  
  ##################
  ## Step 12:
  ##    Summary Statistics
  ##################
  
  # calling the summary function for weights to obtain summary statistic data
  summary_algo <- summary_fcn_wts(startData=data_sub, 
                                  endData=data_truePeaks_2)
  
  # storing the total number of peaks calculated in this iteration of the algorithm
  #     and saving it as peaks_total
  peaks_total <- ifelse( is.na(unname(table(data_truePeaks_2$wtslope_flag)[2])), 
                         0, unname(table(data_truePeaks_2$wtslope_flag)[2]))
  
  
  
  
  # return the dataset with the repeated heights information removed
  return(list( dataset_it = data_noPeaks, summaryMatrix = summary_algo, peaks = peaks_total))
  
}



################################################################################
# PROGRAM: Weight_IterativeLoop
# DESCRIPTION: This function will remove all repeated weight observations and
#               remove all anomaly peaks detected from the algorithm
################################################################################

################################################################################
#   INPUT:
#           data:           the dataset that the algorithm will be ran on. 
#           maxpeaks:       the maximum number of peaks desired in dataset
#           maxiterations:  the maximum number of iterations to be computed
#           userAgeVar:     character variable that identifies age in dataset
#           userWeightVar:  character variable that identifies weight in dataset
#           userIDVar:      character variable that identifies patients in dataset
#           userSourceVar:  character variable that identifies source of observation in dataset
#           summaryPath:    character variable specifying desired path for summary statistic excel sheet
#           outputName:     character variable specifying desired name for summary statistic excel sheet
################################################################################

Weight_IterativeLoop <- function( data, maxpeaks, maxiterations,
                                  userAgeVar, userWeightVar, userIDVar, userSourceVar,
                                  summaryPath, outputName) {
  
  # first, we need to rename the variables in the original dataset to the ones required
  #         for the implementation of the algorithm
  colnames(data)[which(colnames(data)==userAgeVar)] = "ageyearsnew"
  colnames(data)[which(colnames(data)==userIDVar)] = "PID"
  colnames(data)[which(colnames(data)==userSourceVar)] = "source"
  colnames(data)[which(colnames(data)==userWeightVar)] = "wtkg"
  
  # Now this function will remove the height repeats in the dataset and calculate initial peaks 
  Data_Iteration_0 <- Remove_Repeats_WT(data)
  
  iteration = 0 # initialize the iteration number before running the loop 
  peaks = 5     # set arbitrary peak number to initialize the beginning of the loop
  
  # create a list to save each iteration's data
  iteration_data <- list()
  
  repeat{
    
    # create name for next iteration's data
    dataName <- paste0("Data_Iteration_", iteration + 1)
    #create name for previous iteration's data
    dataName_Prev <- paste0("Data_Iteration_", iteration)
    # call the Remove_Peaks function to the previous data's information
    iteration_data[[iteration+1]] <- assign(dataName, Remove_Peaks_WT(data=get(dataName_Prev)))
    
    # extracting the number of peaks detected in the iteration to utilize in the if then statements below 
    peaks_detected <- get(dataName)[[3]]
    
    # if the peaks detected are greater than the ones specified by the user, this code
    #     prints the number of peaks detected
    if ( peaks_detected > maxpeaks) {
      print( paste0("The algorithm detected  ", peaks_detected, " peaks"))
      
    } 
    
    # if the peaks detected are equal to or less than specification by user OR
    #     the number of iterations exceed iterations desired by user, the 
    #     number of peaks will be output and then the repeat loop will be exited
    if ( (peaks_detected <= maxpeaks) | (iteration > maxiterations) ){
      print( paste0("The algorithm detected  ", peaks_detected, " peaks"))
      break
    }
    
    iteration = iteration + 1 #updating the iteration number
    
    
  } # end of repeat block
  
  # initializing a vector for names of the each iteration
  names <- c()
  # creating a names vector for the list
  for (i in 1:(iteration+1)) {
    names[i] = paste0("Iteration_", i)
  }
  
  # assigning created names to the iteration_data matrix
  names(iteration_data) <- names
  
  # initializing a new matrix
  summary_list <- matrix(nrow =0, ncol=10)
  # creating singular summary matrix
  for (i in 1:(iteration+1)) {
    matName <- paste0("Summary", i)
    assign(matName, iteration_data[[i]][["summaryMatrix"]])
    summary_list <- rbind(summary_list, get(matName))
  }
  # create a vector that contains the number of iterations 
  iterations <- seq(1, iteration+1)
  # replace the first column with this sequential vector
  summary_list[,1] <- iterations
  
  # saves the summary list as a dataframe for easy export
  df.summary_list <- data.frame(summary_list)
  
  # uses conditional logic to create the path for the file
  #     - if the user's path does not end in /, then we will add it along with the 
  #           desired outputName specified by the user with excel extension
  #     - if the user's path ends in /, then we will simply concatenate the output 
  #           name with the excel extension
  if (substr(summaryPath, start=nchar(summaryPath), stop=nchar(summaryPath) ) == "/") {
    filepath <- paste0(summaryPath, outputName, ".xlsx")
  } else if (substr(summaryPath, start=nchar(summaryPath), stop=nchar(summaryPath) ) != "/") {
    filepath <- paste0(summaryPath, "/", outputName, ".xlsx")
  }
  
  # exports the summary_list dataframe to excel file
  write_xlsx(df.summary_list, 
             path = filepath,
             col_names = TRUE)
  
  
  # returns removed heights as first list object, all iterations as another
  #   list object, and a summary statistic matrix that combines all statistics
  #   in one format
  return( list( data_it0= Data_Iteration_0, data_all = iteration_data, 
                summary = summary_list))
} # end of function




################################################################################
# PROGRAM: summary_fcn_wts
# DESCRIPTION: This function will produce a matrix of summary data for each
#                 iteration of the weights anomaly algorithm
################################################################################

################################################################################
#   INPUT:
#           startData:  the dataset that the iteration began with 
#           endData:    the dataset that the iteration computed after running 
#                                   the anomaly algorithm with no peaks removed, 
#                                   just identified
################################################################################

summary_fcn_wts <- function( startData, endData){
  
  # creating a matrix with 10 columns and 1 row
  matrix <- matrix(ncol = 10, nrow=1)
  # naming the columns of the matrix for easy identification
  colnames(matrix) <- c("Iteration number",
                        "Total number of observations prior to removing peaks and repeats", 
                        "Total Number of participants prior to removing peaks and repeats",
                        "Total number of observations after removing peaks and repeats",
                        "Total number of participants after removing peaks and repeats",
                        "Total number of repeats identified",
                        "Total number of peaks identified",
                        "Total number of participants with at least 1 peak",
                        "Maximum number of peaks per participant",
                        "Max percent of a participant's data comprised of peaks")
  # creating a placeholder column for the iteration number
  matrix[1, 1] <- 1
  # the number of observations prior to running the algorithm
  matrix[1, 2] <- nrow(startData)
  # the total number of patients included in the dataset before the algorithm
  matrix[1, 3] <- length(unique(startData$PID))
  # filtering the data to only include observations without repeats and peaks
  rows <- endData %>% filter(wtslope_flag == 0, wtkg_Repeat == 0) 
  # storing the number of observations without repeats and peaks (to be removed at end)
  matrix[1, 4] <- nrow(rows)
  # storing number of unique patients still remaining in the dataset after removing peaks/repeats
  matrix[1, 5] <- length(unique(endData$PID))
  # storing the number of repeats, if the table does not have any then 0 will be returned, otherwise the value 
  #     of the number of repeats will be returned
  matrix[1, 6] <- ifelse( (is.na(unname(table(endData$wtkg_Repeat)[2]))) , 0, unname(table(endData$wtkg_Repeat)[2]))
  # storing the number of peaks, if table does not contain any, 0 will be returned, otherwise the value of 
  #     peaks will be returned
  matrix[1, 7] <- ifelse( is.na(unname(table(endData$wtslope_flag)[2])), 0, unname(table(endData$wtslope_flag)[2])) 
  # creating a summary dataset that contains the number of peaks per patient
  maxPeaks     <- endData %>% group_by(PID) %>% summarise(numPeaks = sum(wtslope_flag))
  # storing the value of the highest number of peaks contained within a singular participant
  matrix[1, 9] <- max(maxPeaks$numPeaks)
  # storing the value of how many participants had more than one peak
  matrix[1, 8] <- length(which(maxPeaks$numPeaks >=1)) # add condition to avoid 
  # creating a summary of the number of peaks per participant, then creating a variable that calculates
  #       the percent of their data are "peak" values
  MaxPID_Summary <- endData %>% group_by(PID) %>% 
    summarise(records = n(), numPeaks = sum(wtslope_flag)) %>% 
    mutate(percent = (numPeaks/records)*100)
  # storing the maximum value from the above dataset to the matrix
  matrix[1, 10] <- max(MaxPID_Summary$percent)
  
  # returns the final summary statistics produced in the function
  return(matrix)
}




################################################################################
# PROGRAM: renameVars
# DESCRIPTION: This function will change the name of the user supplied rows
################################################################################

################################################################################
#   INPUT:
#           data: the dataset that the algorithm will be ran on. 
#                   must have specified variables ....
#           userAgeVar: The user provided name capturing the age information
#           userHeightVar: The user provided name capturing height information
#           userIDVar: The user provided name that characterizing which participant
#                         the data belongs to (an ID variable)
#           userSourceVar: The way in which the data will be sorted
################################################################################

renameVars <- function(data, userAgeVar, userHeightVar, userIDVar, userSourceVar){
  #rename the variable to match what you want, I think for age is "ageyrs".  You can also do this for more variables if need be
  colnames(data)[which(colnames(data)==userAgeVar)] = "ageyearsnew"
  colnames(data)[which(colnames(data)==userHeightVar)] = "lgcm"
  colnames(data)[which(colnames(data)==userIDVar)] = "PID"
  colnames(data)[which(colnames(data)==userSourceVar)] = "source"
  return(data)
}
















