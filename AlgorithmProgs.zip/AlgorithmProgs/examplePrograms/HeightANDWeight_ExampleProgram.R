################################################################################
# PROGRAM: HeightWeight_Example Program
# DESCRIPTION: This program provides an example of how to implement the 
#                 anomaly algorithm for height and weight data 
################################################################################


# Step One: Ensure that the required packages are installed to your version 
#               of R and load functions needed
install.packages("tidyverse", "writexl")

### load the packages into current session of R
library(tidyverse)
library(writexl)

### load the functions

## establish path to required functions on pc (make sure to have / as the last character)
functionpath <- "path to folder where functions are stored"

##### -FunctionFileHeight:       File containing all functions required for Harrall Algorithm (height)
##### -FunctionFileHeight:       File containing all functions required for Harrall Algorithm (weight)
source(paste0(functionpath, "p002_FunctionFileHeight.R"))
source(paste0(functionpath, "p002_FunctionFileWeight.R"))

# Step Two: Load your data into R
filename = "path to file here"
data <- read.csv(filename)



# Step Three: Run the Anomaly Algorithm

## create variables in R session for each of the following required arguments in 
##        the iterative loop
outputHt    <- "path to folder for height cleaning data"
outputWt    <- "path to folder for weight cleaning data"
outDSNameHt <- "Name of Excel File for height cleaning data"
outDSNameWt <- "Name of Excel File for weight cleaning data"
age         <- "Name of age variable in dataset"
height      <- "Name of height variable in dataset"
weight      <- "Name of weight variable in dataset"
ID          <- "Name of patient identifier in dataset"
source      <- "Name of source variable in dataset"

# this step will clean the heights 
HtCleanedData <- Height_IterativeLoop(data=data, maxpeaks=0, maxiterations=100,
                                      userAgeVar = age, userHeightVar = height, 
                                      userIDVar = ID, userSourceVar = source,
                                      summaryPath = outputHt, outputName = outDSNameHt)

## now we can save final output from last iteration in one object as a data frame
i = # number of iterations computed
CleanHts <- HtCleanedData[[2]][[i]][[1]]


# This step will take the cleaned height dataset and perform the weight anomaly algorithm on it
WtCleanedData <- Weight_IterativeLoop(data=CleanHts, maxpeaks=0, maxiterations=100,
                                      userAgeVar = age, userWeightVar = weight, 
                                      userIDVar = ID, userSourceVar = source,
                                      summaryPath = outputWt, outputName = outDSNameWt)


## Output is in list form
####  - First element in the list is the dataset with removed repeats and preliminary peak calculations
####  - Second element in the list is a list of all iterations of the anomaly algorithm performed. For each iteration
####    notice that it contains:
####        - a) the dataset with peaks removed from that iteration
####        - b) a summary statistic matrix from that iteration
####        - c) the number of peaks calculated in the iteration of the algorithm
####  - Third element in the list is a matrix that combines the summary statistics across all iterations




