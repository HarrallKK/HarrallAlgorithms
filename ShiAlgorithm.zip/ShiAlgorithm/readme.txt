Folder: ShiAlgorithm
Purpose: This folder contains programs that will calculate sensitivity and specificity from datasets that
have been processed by the Shi Algorithm.

Files:
	- p001_ProcessingShi: This program contains an internal macro that is used to process the datasets
		after having been run through the Phan algorithm pipeline.
	- p001_ShiSastoCSV: This program is composed of a macro that converts the simulated datasets to the
		form (in a CSV data type) needed for the Phan algorithm application.
	- p001_ShiSensitivity: This program calculates the sensitivity and specificity of the algorithm on 
		the simulated datasets.
	- p040_ShiSensSpec_HtWt: This program contains a macro that calculates sensitivity and specificity 
		on the simulated datasets. Included in p001_ShiSensitivity.
	- p004_processingFile.do: This is a Stata file that will run the Shi algorithm on each of the simulated
		datasets and store the resulting data and timing information.

Folders:
	- DatasetConversion: This folder contains code extracted from the CDC to calculate the required argument
		of Z-scores for use in the Shi algorithm. The code and associated data file can more formally 
		be found here (https://www.cdc.gov/growthcharts/cdc_charts.htm)