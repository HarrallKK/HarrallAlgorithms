##########################################
#
#   PROGRAM: p002_DaymontSensitivitySpecificity
#   Author: Sarah Bird
#   Date Last Edited: June 28th, 2023
#
##########################################

# libraries needed
library(data.table)
library(tidyverse)
library(haven)
library(growthcleanr)

### Setting up naming conventions

# First establish the directory where all the dirty datasets are located
directory <- "[path to directory where dirty datasets are]"
# Now, gather all of the dataset names together in a list format
datasets <- dir(path = directory, pattern = "data_\\d+_\\d+_\\d+")

### Set up final dataset that data will be appended to
SensSpec <- tibble(  h_d_N11               = numeric(),
                     h_d_N12               = numeric(),
                     h_d_N21               = numeric(),
                     h_d_N22               = numeric(),
                     h_d_sens              = numeric(),
                     h_d_spec              = numeric(),
                     h_d_avg_sens_part     = numeric(),
                     h_d_avg_spec_part     = numeric(),
                     w_d_N11               = numeric(),
                     w_d_N12               = numeric(),
                     w_d_N21               = numeric(),
                     w_d_N22               = numeric(),
                     w_d_sens              = numeric(),
                     w_d_spec              = numeric(),
                     w_d_avg_sens_part     = numeric(),
                     w_d_avg_spec_part     = numeric(),
                     dirtlvl               = numeric(),
                     poplvl                = numeric(),
                     itlvl                 = numeric())
# Set up final dataset that the time run will be appended to
times <- tibble(start_time_ht   = numeric(),
                end_time_ht     = numeric(),
                start_time_wt   = numeric(),
                end_time_wt     = numeric(),
                dirtlvl         = numeric(),
                poplvl          = numeric(),
                itlvl           = numeric(),
                ht_length       = numeric(),
                wt_length       = numeric())


# Iterative loop
for (i in 0:10000) {

  # create the path
  path <- paste(directory, datasets[i], sep="/")
  # read in the data
  data <- read_sas(path) %>% select(!c(total_obs, next_seed, pred_ht, pred_wt))
  # reformat the data for height
  data_ht <- data %>% mutate(subjid = PID, param = "HEIGHTCM", agedays = 365*ageyrs,
                             sex = ifelse(gender == "F", 1, 0), measurement = ht) %>%
    select(subjid, param, agedays, sex, measurement, type:bad_ht)
  # reformat the data for weight
  data_wt <- data %>% mutate(subjid = PID, param = "WEIGHTKG", agedays = 365*ageyrs,
                             sex = ifelse(gender == "F", 1, 0), measurement = wt) %>%
    select(subjid, param, agedays, sex, measurement, type, why, bad_wt)

  ######################
  #
  # Run Algo on Height
  #
  ######################

  # prepare data as a data.table
  ht <- as.data.table(data_ht)
  wt <- as.data.table(data_wt)
  rm(data_ht, data, data_wt)

  # set the data.table key for better indexing
  setkey(ht, subjid, param, agedays)
  setkey(wt, subjid, param, agedays)

  # start time and cleaning for height
  # start_time_ht   <- as.integer(format(Sys.time(), "%M%S"))
  start_time_ht   <- Sys.time()
  cleaned_data_ht <- ht[, gcr_result := cleangrowth(subjid, param, agedays, sex, measurement)]
  end_time_ht     <- Sys.time()
  # end_time_ht     <- as.integer(format(Sys.time(), "%M%S"))

  # start time and cleaning for weight
  start_time_wt   <- Sys.time()
  cleaned_data_wt <- wt[, gcr_result := cleangrowth(subjid, param, agedays, sex, measurement)]
  end_time_wt     <- Sys.time()

  # calculate sensitivities and specificities
  cln.hts.spec <- sensSpecCalc(var = "ht", clean.data = cleaned_data_ht)
  cln.wts.spec <- sensSpecCalc(var = "wt", clean.data = cleaned_data_wt)

  # extract the population, dirt, and iteration levels
  lvls <- as.numeric(unlist(str_split(str_extract(datasets[i], pattern = "\\d+_\\d+_\\d+"), pattern = "_")))

  # merge these together
  variables <- cbind(cln.hts.spec, cln.wts.spec, poplvl = lvls[1], dirtlvl = lvls[2] , itlvl=lvls[3])
  SensSpec <- rbind(SensSpec, variables)

  # now compile the time dataset needed
  time_vars <- cbind(start_time_ht, start_time_wt, end_time_ht, end_time_wt,
                     poplvl = lvls[1], dirtlvl = lvls[2] , itlvl=lvls[3],
                     ht_length = end_time_ht - start_time_ht,
                     wt_length = end_time_wt - start_time_wt)
  times <- rbind(times, time_vars)

  # Remove unnecessary objects
  rm(cln.hts.spec, cln.wts.spec, ht, wt, variables, lvls, path,cleaned_data_ht, cleaned_data_wt )
  rm(start_time_ht, start_time_wt, end_time_ht, end_time_wt, time_vars)

}













