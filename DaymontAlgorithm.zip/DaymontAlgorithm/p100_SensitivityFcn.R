##########################################
#
#   PROGRAM: p100_SensitivityFcn
#   Author: Sarah Bird
#   Date Last Edited: June 28th, 2023
#
##########################################

###############################################################################
# Function:  sensSpecCalc                                                     #
# Description:  To compute sensitvity and specificity metrics on the Daymont  #
#                 algorithm                                                   #
###############################################################################
# Inputs:                                                                     #
#           Var: Variable to be processed and cleaned                         #
#           clean.data: name of output dataset                                #
###############################################################################
# Outputs:                                                                    #
#           clean.data: Dataset containing sensitivity and specificity        #
#           times: Dataset containing timing data for each evaluation of      #
#                     the Daymont algorithm                                   #
###############################################################################
sensSpecCalc <- function(var, clean.data) {

  # If variable is height
  if(var == "ht") {
    # Create 2x2 table categorizations for each observation in dataset
    clean.data <- clean.data %>% mutate( cleaned.out = ifelse(grepl("Exclude", gcr_result), 1, 0)) %>%
      mutate(counts = case_when(
        (is.na(bad_ht) | is.na(cleaned.out)) ~ "missing",
        (bad_ht == 0) & (cleaned.out == 0) ~ "N11",
        (bad_ht == 0) & (cleaned.out == 1) ~ "N21",
        (bad_ht == 1) & (cleaned.out == 0) ~ "N12",
        (bad_ht == 1) & (cleaned.out == 1) ~ "N22",
        TRUE ~ "n/a"

      ))

    # obtain per-participant specificity and sensitivity
    sens_spec_part <- clean.data  %>%
      mutate(counts = factor(counts, levels = c("N11", "N12", "N21", "N22"))) %>%
      count(subjid, counts, .drop=FALSE) %>%  pivot_wider(names_from = counts,
                                                          values_from = n,
                                                          id_cols = subjid) %>%
      mutate(h_d_sens = ifelse( is.na(N11) | is.na(N21), NA, ifelse((N11 + N21) == 0 ,NA,
                                                                    N11 / ((N11 + N21)))),
             h_d_spec = ifelse( is.na(N22) | is.na(N12), NA, ifelse((N22 + N12) == 0 ,NA,
                                                                    N22 / ((N22 + N12))))) %>%
      summarize(h_d_sens_avg_part = mean(h_d_sens, na.rm = TRUE),
                h_d_spec_avg_part = mean(h_d_spec, na.rm=TRUE)) %>%
      mutate(h_d_sens_avg_part = ifelse( !is.nan(h_d_sens_avg_part), h_d_sens_avg_part, 0),
             h_d_spec_avg_part = ifelse( !is.nan(h_d_spec_avg_part), h_d_spec_avg_part, NA))

    ## Obtaining sensitivity specificity for the whole dataset
    sens_spec2 <- clean.data %>% mutate(counts = factor(counts, levels = c("N11", "N12", "N21", "N22"))) %>%
      count(counts, .drop=FALSE) %>% pivot_wider(names_from = counts,
                                                 values_from = n) %>%
      mutate( h_d_N11 = N11 ,
              h_d_N12 = N12 ,
              h_d_N21 = N21 ,
              h_d_N22 = N22) %>%
      mutate(h_d_sens = ifelse( is.na(h_d_N11) | is.na(h_d_N21), NA, ifelse((h_d_N11 + h_d_N21) == 0 ,NA,
                                                                            h_d_N11 / ((h_d_N11 + h_d_N21)))),
             h_d_spec = ifelse( is.na(h_d_N22) | is.na(h_d_N12), NA, ifelse((h_d_N22 + h_d_N12) == 0 ,NA,
                                                                            h_d_N22 / ((h_d_N22 + h_d_N12))))) %>%
      select(!c(N11, N12, N21, N22))

  } else if (var == "wt") {
    clean.data <- clean.data %>% mutate( cleaned.out = ifelse(grepl("Exclude", gcr_result), 1, 0)) %>%
      mutate(counts = case_when(
        (is.na(bad_wt) | is.na(cleaned.out)) ~ "missing",
        (bad_wt == 0) & (cleaned.out == 0) ~ "N11",
        (bad_wt == 0) & (cleaned.out == 1) ~ "N21",
        (bad_wt == 1) & (cleaned.out == 0) ~ "N12",
        (bad_wt == 1) & (cleaned.out == 1) ~ "N22",
        TRUE ~ "n/a"

      ))

    # obtain per-participant specificity and sensitivity
    sens_spec_part <- clean.data  %>%
      mutate(counts = factor(counts, levels = c("N11", "N12", "N21", "N22"))) %>%
      count(subjid, counts, .drop=FALSE) %>%  pivot_wider(names_from = counts,
                                                       values_from = n,
                                                       id_cols = subjid) %>%
      mutate(w_d_sens = ifelse( is.na(N11) | is.na(N21), NA, ifelse((N11 + N21) == 0 ,NA,
                                                                    N11 / ((N11 + N21)))),
             w_d_spec = ifelse( is.na(N22) | is.na(N12), NA, ifelse((N22 + N12) == 0 ,NA,
                                                                    N22 / ((N22 + N12))))) %>%
      summarize(w_d_sens_avg_part = mean(w_d_sens, na.rm = TRUE),
                w_d_spec_avg_part = mean(w_d_spec, na.rm=TRUE)) %>%
      mutate(w_d_sens_avg_part = ifelse( !is.nan(w_d_sens_avg_part), w_d_sens_avg_part, 0),
             w_d_spec_avg_part = ifelse( !is.nan(w_d_spec_avg_part), w_d_spec_avg_part, NA))

    ## Obtaining sensitivity specificity for the whole dataset
    sens_spec2 <- clean.data %>% mutate(counts = factor(counts, levels = c("N11", "N12", "N21", "N22"))) %>%
      count(counts, .drop=FALSE) %>% pivot_wider(names_from = counts,
                                                 values_from = n) %>%
      mutate( w_d_N11 = N11 ,
              w_d_N12 = N12 ,
              w_d_N21 = N21 ,
              w_d_N22 = N22) %>%
      mutate(w_d_sens = ifelse( is.na(w_d_N11) | is.na(w_d_N21), NA, ifelse((w_d_N11 + w_d_N21) == 0 ,NA,
                                                                            w_d_N11 / ((w_d_N11 + w_d_N21)))),
             w_d_spec = ifelse( is.na(w_d_N22) | is.na(w_d_N12), NA, ifelse((w_d_N22 + w_d_N12) == 0 ,NA,
                                                                            w_d_N22 / ((w_d_N22 + w_d_N12))))) %>%
      select(!c(N11, N12, N21, N22))
  } else {
    print("ERROR: Var is unreachable.")
  }

  # Creating summary statistics for sensitivity and specificity
  if (var == "ht"){
    sensspec <- tibble(h_d_N11=sens_spec2$h_d_N11, h_d_N12= sens_spec2$h_d_N12,
                       h_d_N21=sens_spec2$h_d_N21, h_d_N22=sens_spec2$h_d_N22,
                       h_d_sens=sens_spec2$h_d_sens, h_d_spec=sens_spec2$h_d_spec,
                       h_d_sens_avg_part=sens_spec_part$h_d_sens_avg_part,
                       h_d_spec_avg_part=sens_spec_part$h_d_spec_avg_part)
  } else if (var == "wt"){
    sensspec <- tibble(w_d_N11=sens_spec2$w_d_N11, w_d_N12= sens_spec2$w_d_N12,
                       w_d_N21=sens_spec2$w_d_N21, w_d_N22=sens_spec2$w_d_N22,
                       w_d_sens=sens_spec2$w_d_sens, w_d_spec=sens_spec2$w_d_spec,
                       w_d_sens_avg_part=sens_spec_part$w_d_sens_avg_part,
                       w_d_spec_avg_part=sens_spec_part$w_d_spec_avg_part)
  } else {
    print("Error: no variable correct.")
  }

  return(sensspec)

}



