##########################################
#
#   PROGRAM: p001_TableSummaries
#   Author: Sarah Bird
#   Date Last Edited: July 18th, 2023
#
##########################################

# To obtain mean sensitivity and specificity by level of dirt in the data
summary_lvl <- SensSpec %>% group_by(dirtlvl) %>%
  summarise( h_sens = mean(h_d_sens, na.rm = TRUE),
             h_sd_sens = sd(h_d_sens, na.rm = TRUE),
             h_spec = mean(h_d_spec, na.rm = TRUE),
             h_sd_spec = sd(h_d_spec, na.rm = TRUE),
             w_sens = mean(w_d_sens, na.rm = TRUE),
             w_sd_sens = sd(w_d_sens, na.rm = TRUE),
             w_spec = mean(w_d_spec, na.rm = TRUE),
             w_sd_spec = sd(w_d_spec, na.rm = TRUE)) %>% ungroup()

# To obtain the overall mean sensitivity and specificity
summary_overall <- SensSpec %>%
  summarise( h_sens = mean(h_d_sens, na.rm = TRUE),
             h_spec = mean(h_d_spec, na.rm = TRUE),
             w_sens = mean(w_d_sens, na.rm = TRUE),
             w_spec = mean(w_d_spec, na.rm = TRUE))

# To obtain mean and sd of run time by level of dirt in the data
run_time_lvl <- times %>% group_by(dirtlvl) %>%
  summarise( h_run_time = mean(ht_length, na.rm = TRUE),
             h_sd_run   = sd(ht_length, na.rm = TRUE),
             w_run_time = mean(wt_length, na.rm = TRUE),
             w_sd_run   = sd(wt_length, na.rm = TRUE))

# To obtain mean and sd of run time by level of dirt in the data
run_time_overall <- times %>%
  summarise( h_run_time = mean(ht_length, na.rm = TRUE),
             h_sd_run   = sd(ht_length, na.rm = TRUE),
             w_run_time = mean(wt_length, na.rm = TRUE),
             w_sd_run   = sd(wt_length, na.rm = TRUE))










