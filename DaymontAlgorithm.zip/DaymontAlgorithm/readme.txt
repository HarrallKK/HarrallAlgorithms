Folder: DaymontAlgorithm
Purpose: To contain code that implements the Daymont cleaning pipeline across all simulated 
datasets, then calculate sensitivity and specificity values associated with each dataset.

Files:
	- p001_TableSummaries: Summary functions that calculate the overall means and standard
		deviations for the simulated datasets.
	- p002_DaymontSensitivitySpecificity: The loop that iterates through all of the simulated
		datasets in a file, then computes sensitivity, specificity, and run time.
	- p100_SensitivityFcn: A file that contains the function for computing sensitivity and
		specificity.
