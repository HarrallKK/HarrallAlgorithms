Folder: PhanAlgorithm
Purpose: The SAS files in this folder are responsible for running the Phan Algorithm on the simulated
datasets. 

Files:
	- p001_PhanSasToCSV: This program takes in the simulated datasets and transforms them to the 
		specified form in order to run the Phan algorithm on them.
	- p001_PhanSensitivity: This file contains the macro that will calculate sensitivity and specificity
		from the results of the Phan cleaning algorithm.
	- p001_ProcessingPhan: This program contains a macro that is used in the processing of the Phan data.
	- p040_PhanSensitivitySpecificity_HtWt: This program contains a macro used for the calculation of sensitivity
		and specificity.
	- p004_batch_run: This file was used to loop through and implement the phan algorithm on all of the
		simulated datasets