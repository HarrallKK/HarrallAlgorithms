import os
import subprocess
import pandas as pd
import time

# Path to your Python script that processes the dataset (peanof.py)
python_script = "python3 peanof2.py"

# Command template to run the peanof.py script on a dataset
command_template = "{} -n 1 -f {} -o {}"

# Path to the directory containing the CSV datasets
csv_dataset_directory = 'SimData/rawData'

# Path to the directory where you want to save the output CSV files
output_directory = 'SimData/processedData'


# Define the name of the output CSV file
output_csv_file = "time_data_output.csv"

# Define the full path for the output CSV file
output_csv_path = os.path.join(output_directory, output_csv_file)

# Create an empty DataFrame to store elapsed times
time_data = pd.DataFrame(columns=['filename', 'elapsed_time'])

# Record the start time of the script execution
script_start_time = time.time()

# List all the files in the CSV dataset directory
csv_files = os.listdir(csv_dataset_directory)

# Loop through each file in the directory
for csv_file in csv_files:
    # Check if the file is a CSV dataset (you may need to modify this condition based on your filenames)
    if csv_file.endswith(".csv"):
        # Get the full path of the input and output files
        input_file = os.path.join(csv_dataset_directory, csv_file)
        output_file = os.path.join(output_directory, f"{os.path.splitext(csv_file)[0]}_out.csv")

        # Construct the command with the appropriate input and output file paths
        command = command_template.format(python_script, input_file, output_file)

        # Measure the time taken to process the dataset
        start_time = time.time()

        # Run the Python script (peanof.py) on the dataset using subprocess
        subprocess.run(command, shell=True, check=True)

        # Calculate the time taken to process the dataset
        end_time = time.time()
        elapsed_time = end_time - start_time

        # Add elapsed time data to the time_data DataFrame using pandas.concat()
        time_data = pd.concat([time_data, pd.DataFrame({'filename': [csv_file], 'elapsed_time': [elapsed_time]})],
                              ignore_index=True)

        print(f"Processed {csv_file} in {elapsed_time:.2f} seconds")

# Record the end time of the script execution
script_end_time = time.time()

# Calculate the total script execution time
total_script_execution_time = script_end_time - script_start_time

# Add the total script execution time to the time_data DataFrame
time_data = pd.concat([time_data, pd.DataFrame({'filename': ['ScriptExecutionTime'], 'elapsed_time': [total_script_execution_time]})],
                      ignore_index=True)

print(f"Total script execution time: {total_script_execution_time:.2f} seconds")

# Save the elapsed times DataFrame to the output CSV file
time_data.to_csv(output_csv_path, index=False)
