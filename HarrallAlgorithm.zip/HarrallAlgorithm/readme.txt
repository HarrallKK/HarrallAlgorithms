Folder: HarrallAlgorithm
Purpose: The SAS files in this folder are responsible for running the Harrall Algorithm on the simulated
datasets. 

Files:

	- p040_HarrallSensSpec_HtWt: This program contains a SAS macro that will calculate the sensitivity and
		specificity of the Harral Algorithm on a given dataset.
	- p100_HarrallAlgorithm: This program contains a macro that will take in all simulated datasets, run
		the Harrall Algorithm on those simulated datasets, then output a file containing sensitivity
		and specificity of the given datasets. 